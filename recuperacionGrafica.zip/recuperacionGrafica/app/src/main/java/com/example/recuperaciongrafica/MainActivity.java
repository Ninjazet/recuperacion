package com.example.recuperaciongrafica;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.face.Face;
import com.google.mlkit.vision.face.FaceDetection;
import com.google.mlkit.vision.face.FaceDetector;
import com.google.mlkit.vision.face.FaceDetectorOptions;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int CAMERA_REQUEST = 1;
    private static final int PERMISSION_REQUEST_CODE = 100;
    private Bitmap imagenTomada;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Verificar si el permiso ya está concedido
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            // Si no está concedido, solicitamos el permiso
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, PERMISSION_REQUEST_CODE);
        }
    }


    // Método para abrir la cámara desde el botón
    public void abrirCamara(View view) {
        // Verificar si el permiso ha sido concedido antes de abrir la cámara
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            Intent camaraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            startActivityForResult(camaraIntent, CAMERA_REQUEST); // Inicia la cámara
        } else {
            // Solicitar permisos si no están concedidos
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, PERMISSION_REQUEST_CODE);
        }
    }

    // Método para manejar el resultado de la foto tomada
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST && resultCode == RESULT_OK) {
            if (data != null) {
                // Tomamos la foto directamente desde el Intent
                Bundle extras = data.getExtras();
                if (extras != null) {
                    imagenTomada = (Bitmap) extras.get("data"); // Obtenemos la imagen en formato Bitmap
                    // Mostrar la imagen en la ImageView
                    ImageView imageView = findViewById(R.id.imagen_seleccionada);
                    imageView.setImageBitmap(imagenTomada); // Cargar imagen en la ImageView

                    // Llamar a la función para detectar rostros
                    detectarRostros(imagenTomada);
                }
            }
        }
    }

    // Método para detectar rostros en la imagen usando ML Kit
    private void detectarRostros(Bitmap bitmap) {
        InputImage image = InputImage.fromBitmap(bitmap, 0);

        FaceDetectorOptions options =
                new FaceDetectorOptions.Builder()
                        .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                        .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                        .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL) // Esto es esencial
                        .build();

        FaceDetector detector = FaceDetection.getClient(options);

        detector.process(image)
                .addOnSuccessListener(
                        faces -> {
                            if (faces.isEmpty()) {
                                // No se detectó rostro
                                showToast("No se detectó ningún rostro.");
                                TextView personaDetectadaTextView = findViewById(R.id.persona_detectada);
                                personaDetectadaTextView.setText("No se detectó persona");
                            } else {
                                // Se detectó rostro
                                TextView personaDetectadaTextView = findViewById(R.id.persona_detectada);
                                personaDetectadaTextView.setText("Persona detectada");

                                // Crear un Bitmap mutable para dibujar sobre él
                                Bitmap imagenConRostros = imagenTomada.copy(Bitmap.Config.ARGB_8888, true);

                                // Crear un Canvas y Paint para dibujar el rectángulo
                                Canvas canvas = new Canvas(imagenConRostros);
                                Paint paint = new Paint();
                                paint.setColor(Color.RED); // Color del borde
                                paint.setStyle(Paint.Style.STROKE); // Estilo de borde
                                paint.setStrokeWidth(5); // Grosor del borde

                                for (Face face : faces) {
                                    // Obtener las coordenadas del rostro
                                    RectF rostroRect = new RectF(face.getBoundingBox());

                                    // Dibujar el rectángulo alrededor del rostro
                                    canvas.drawRect(rostroRect, paint);

                                    // Verificar sonrisa
                                    verificarSonrisa(face);
                                }

                                // Mostrar la imagen con los rectángulos en la ImageView
                                ImageView imageView = findViewById(R.id.imagen_seleccionada);
                                imageView.setImageBitmap(imagenConRostros); // Cargar imagen modificada
                            }
                        })
                .addOnFailureListener(
                        e -> {
                            showToast("Error al detectar rostros: " + e.getMessage());
                        });
    }

    private void verificarSonrisa(Face face) {
        // Obtener la probabilidad de sonrisa
        float smilingProbability = face.getSmilingProbability();

        // Verificar si la probabilidad de sonrisa es mayor que un umbral (por ejemplo, 0.5)
        if (!Float.isNaN(smilingProbability)) {
            TextView sonrisaTextView = findViewById(R.id.sonrisa);

            if (smilingProbability > 0.5f) {
                // Si la probabilidad de sonrisa es mayor que 0.5, consideramos que la persona está sonriendo
                sonrisaTextView.setText("Persona sonriendo");
                sonrisaTextView.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            } else {
                // Si la probabilidad de sonrisa es baja, no está sonriendo
                sonrisaTextView.setText("No está sonriendo");
                sonrisaTextView.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            }
        } else {
            showToast("No se pudo calcular la probabilidad de sonrisa.");
        }
    }

    private void verificarOjosCerrados(Face face) {
        float leftEyeOpenProbability = face.getLeftEyeOpenProbability();
        float rightEyeOpenProbability = face.getRightEyeOpenProbability();
        float umbral = 0.5f;

        Log.d("DEBUG", "Probabilidad ojo izquierdo: " + leftEyeOpenProbability);
        Log.d("DEBUG", "Probabilidad ojo derecho: " + rightEyeOpenProbability);

        if (!Float.isNaN(leftEyeOpenProbability) && !Float.isNaN(rightEyeOpenProbability)) {
            TextView ojosCerradosTextView = findViewById(R.id.ojos_cerrados);

            if (leftEyeOpenProbability < umbral && rightEyeOpenProbability < umbral) {
                ojosCerradosTextView.setText("Ambos ojos cerrados");
                ojosCerradosTextView.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark));
            } else {
                ojosCerradosTextView.setText("Ojos cerrados");
                ojosCerradosTextView.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_dark));
            }
        } else {
            showToast("No se pudo calcular la visibilidad de los ojos.");
        }
    }


    // Manejo de permisos
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showToast("Permiso concedido");
                // Permiso concedido, ahora se puede abrir la cámara
                abrirCamara(null);
            } else {
                showToast("Permiso denegado. Necesitas conceder el permiso para acceder a la cámara.");
            }
        }
    }

    // Método para mostrar un Toast con el mensaje pasado como parámetro
    private void showToast(String mensaje) {
        Toast.makeText(this, mensaje, Toast.LENGTH_LONG).show();
    }
}




